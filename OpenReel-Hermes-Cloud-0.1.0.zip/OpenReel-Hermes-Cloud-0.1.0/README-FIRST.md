# Ready-to-add files for your OpenReel fork

Copy the entire `hermes-cloud` directory to the ROOT of your OpenReel fork, alongside `apps` and `packages`.

Start with `hermes-cloud/README-FA.md` for Railway deployment, optional Vercel console, and Hermes connection.

This package contains executable source, a locked dependency list, tests, Docker and deployment configuration. It is not an already deployed service and does not contain your SAAM source, credentials or Google account tokens.

Only the lightweight Python connector/client run on your VPS. The Node server and FFmpeg run on your cloud service.
